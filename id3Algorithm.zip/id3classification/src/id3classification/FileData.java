/***********************************************************
#                   CSCI-B 565 DATA MINING
#                         Homework III
#                       Morning Class
#                    Computer Science Core
#                          Spring
#                     Indiana University,
#                       Bloomington, IN
#                       Nayana Charwad
#                    ncharwad@umail.iu.edu
#                       March 16 2015
#**********************************************************/
package id3classification;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class FileData {

	public void readInputFile(String fileName, ArrayList<String> userData) {
		FileReader fread = null;
		String inputLine = null;

		try {
			fread = new FileReader(fileName);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		BufferedReader fbuffer = new BufferedReader(fread);

		try {
			while ((inputLine = fbuffer.readLine()) != null) {
				userData.add(inputLine);
			}
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		try {
			fbuffer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void writeOutputFile(String fileName,
			ArrayList<String> outputUserData) {
		FileWriter fwrite = null;

		try {
			fwrite = new FileWriter(fileName);
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		BufferedWriter fbuffer = new BufferedWriter(fwrite);

		for (String outputLine : outputUserData) {
			try {
				fbuffer.write(outputLine);
				fbuffer.newLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		try {
			fbuffer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
