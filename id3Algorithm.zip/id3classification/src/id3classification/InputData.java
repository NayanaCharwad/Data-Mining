/***********************************************************
#                   CSCI-B 565 DATA MINING
#                         Homework III
#                       Morning Class
#                    Computer Science Core
#                          Spring
#                     Indiana University,
#                       Bloomington, IN
#                       Nayana Charwad
#                    ncharwad@umail.iu.edu
#                       March 16 2015
#**********************************************************/
package id3classification;

public class InputData {

//table columns	
	int tupleId;
	String columnA;
	String columnB;
	String columnC;
	String columnD;
	
	public int getTupleId() {
		return tupleId;
	}
	
	public void setTupleId(int tupleId) {
		this.tupleId = tupleId;
	}
	
	public String getColumnA() {
		return columnA;
	}
	
	public void setColumnA(String columnA) {
		this.columnA = columnA;
	}
	
	public String getColumnB() {
		return columnB;
	}
	
	public void setColumnB(String columnB) {
		this.columnB = columnB;
	}
	
	public String getColumnC() {
		return columnC;
	}
	
	public void setColumnC(String columnC) {
		this.columnC = columnC;
	}
	
	public String getColumnD() {
		return columnD;
	}
	
	public void setColumnD(String columnD) {
		this.columnD = columnD;
	}
		
}
