/***********************************************************
#                   CSCI-B 565 DATA MINING
#                         Homework III
#                       Morning Class
#                    Computer Science Core
#                          Spring
#                     Indiana University,
#                       Bloomington, IN
#                       Nayana Charwad
#                    ncharwad@umail.iu.edu
#                       March 16 2015
#**********************************************************/

package id3classification;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ID3ClassificationAlgorithm {

	public static void main(String[] args) {

		ArrayList<InputData> dataObject = new ArrayList<InputData>();
		ArrayList<String> buildTreeData = new ArrayList<String>();
		ArrayList<String> inputUserData = new ArrayList<String>();
		ArrayList<String> outputUserData = new ArrayList<String>();

		TreeNode id3Tree = new TreeNode();
		TreeNode root = new TreeNode();

		String buildFile = null;
		String inputFile = null;
		String outputFile = null;

		FileData inputRead = new FileData();

		DatabaseConnectMySQL dbConnect = new DatabaseConnectMySQL();

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("ID3 Algorithm");

		System.out.println("Step 1: Enter Input Build Tree File Path");
		try {
			buildFile = in.readLine();
			inputRead.readInputFile(buildFile, buildTreeData);
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("Step 2: Enter Input File Path");
		try {
			inputFile = in.readLine();
			inputRead.readInputFile(inputFile, inputUserData);
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("Step 3: Enter Output File Path");
		try {
			outputFile = in.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// temporary adjustment to take input variables directly in program
		buildFile = "C:\\Users\\Nayana\\Desktop\\tree.txt";
		inputRead.readInputFile(buildFile, buildTreeData);

		inputFile = "C:\\Users\\Nayana\\Desktop\\test.txt";
		inputRead.readInputFile(inputFile, inputUserData);

		outputFile = "C:\\Users\\Nayana\\Desktop\\output.txt";

		// get data from database
		dbConnect.fetchData(dataObject);

		// display data
		dbConnect.displayData(dataObject);

		// build ID3 classification tree
		root = id3Tree.buildTree(buildTreeData, dataObject);

		// compute probability for each node
		id3Tree.computeNodeProbability(buildTreeData, dataObject, root);

		// search ID3 tree for input data and write results to output table
		id3Tree.searchTree(inputUserData, outputUserData, root);

		// write data to output file
		inputRead.writeOutputFile(outputFile, outputUserData);

		// three fold cross validation
		int recordNumber = 0, index = 0;
		String[] inputAttributesTemp = null;

		// Split input file at spaces to get the corresponding set of attributes
		for (String inLine : buildTreeData) {
			if (index == 0) {
				index++;
				continue;
			} else
				inputAttributesTemp = inLine.split("\\s+");
		}

		for (int iterator = 0; iterator < 3; iterator++) {

			ArrayList<InputData> dataObjectCrossValidation = new ArrayList<InputData>();
			ArrayList<String> inputUserDataCrossValidation = new ArrayList<String>();
			ArrayList<String> outputUserDataCrossValidation = new ArrayList<String>();
			ArrayList<InputData> tempData = new ArrayList<InputData>();
			TreeNode id3TreeCrossValidation = new TreeNode();
			TreeNode rootCrossValidation = new TreeNode();

			for (int counter = 0; counter < 3; counter++) {

				String inputLine = "";

				for (String attribute : inputAttributesTemp) {

					// get corresponding attribute data
					if (attribute.contains("A")) {
						inputLine = inputLine
								+ dataObject.get(recordNumber).getColumnA()
								+ " ";
						// get corresponding attribute data
					} else if (attribute.contains("B")) {
						inputLine = inputLine
								+ dataObject.get(recordNumber).getColumnB()
								+ " ";
						// get corresponding attribute data
					} else if (attribute.contains("C")) {
						inputLine = inputLine
								+ dataObject.get(recordNumber).getColumnC()
								+ " ";
						// get corresponding attribute data
					} else if (attribute.contains("D")) {
						inputLine = inputLine
								+ dataObject.get(recordNumber).getColumnD()
								+ " ";
					}
				}
				inputUserDataCrossValidation.add(inputLine);
				tempData.add(dataObject.get(recordNumber));
				recordNumber++;
			}

			for (InputData inData : dataObject) {

				if (tempData.contains(inData))
					continue;
				else
					dataObjectCrossValidation.add(inData);
			}

			// build ID3 classification tree
			rootCrossValidation = id3TreeCrossValidation.buildTree(
					buildTreeData, dataObjectCrossValidation);

			// compute probability for each node
			id3TreeCrossValidation.computeNodeProbability(buildTreeData,
					dataObjectCrossValidation, rootCrossValidation);

			// search ID3 tree for input data and write results to output table
			id3TreeCrossValidation.searchTree(inputUserDataCrossValidation,
					outputUserDataCrossValidation, rootCrossValidation);

			ArrayList<String> inputLables = new ArrayList<String>();
			ArrayList<Float> averageProbability = new ArrayList<Float>();

			// outputUserDataCrossValidation.remove(8);

			// Split input file at spaces to get the corresponding set of
			// attributes
			for (String inLine : outputUserDataCrossValidation) {

				String[] inputAttributes = inLine.split("\\s+");

				for (int i = 0; i < inputAttributes.length; i++) {
					if (inputAttributes[i].equals("Label")) {
						if (inputLables.contains(inputAttributes[i + 1])) {
							for (int j = 0; j < inputLables.size(); j++) {
								String value = inputLables.get(j);

								if (value.contains(inputAttributes[i + 1])) {
									float addition = averageProbability.get(j);
									addition = addition
											+ Float.parseFloat(inputAttributes[i + 3]);
									averageProbability.set(j, addition);
								}
							}
						} else {
							inputLables.add(inputAttributes[i + 1]);
							averageProbability.add(Float
									.parseFloat(inputAttributes[i + 3]));
						}
					}
				}
			}

			outputUserDataCrossValidation.add("Average Probabilities");

			float error = 0;

			for (int i = 0; i < inputLables.size(); i++) {
				outputUserDataCrossValidation.add("Tuple" + " "
						+ inputLables.get(i) + " " + "Probability" + " "
						+ (averageProbability.get(i) / 3));
				error = error + (averageProbability.get(i) / 3);
			}

			error = 1 - error;

			outputUserDataCrossValidation
					.add("Error because of Average/Probability Unknown" + " "
							+ error);

			if (iterator == 0)
				outputFile = "C:\\Users\\Nayana\\Desktop\\output1.txt";
			else if (iterator == 1)
				outputFile = "C:\\Users\\Nayana\\Desktop\\output2.txt";
			else if (iterator == 2)
				outputFile = "C:\\Users\\Nayana\\Desktop\\output3.txt";

			// write data to output file
			inputRead
					.writeOutputFile(outputFile, outputUserDataCrossValidation);
		}

	}
}
