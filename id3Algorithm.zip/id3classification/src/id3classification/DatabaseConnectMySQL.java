/***********************************************************
#                   CSCI-B 565 DATA MINING
#                         Homework III
#                       Morning Class
#                    Computer Science Core
#                          Spring
#                     Indiana University,
#                       Bloomington, IN
#                       Nayana Charwad
#                    ncharwad@umail.iu.edu
#                       March 16 2015
#**********************************************************/
package id3classification;

import java.sql.*;

import java.util.ArrayList;

public class DatabaseConnectMySQL {

	private Connection connect;
	private Statement statement;
	private ResultSet resultId3Table;

	public DatabaseConnectMySQL() {

		try {
			Class.forName("com.mysql.jdbc.Driver");

			connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/b565_homework3", "root",
					"root");

			statement = connect.createStatement();

		} catch (Exception exception) {
			System.out.println("Error while connection:" + exception);
		}
	}

	public void fetchData(ArrayList<InputData> dataObject) {

		// fetch data from ratings table
		try {
			String queryRatings = "Select * from id3_table";
			resultId3Table = statement.executeQuery(queryRatings);

			// get table data in java array list
			try {

				// iterate through query results and formulate data
				while (resultId3Table.next()) {
					InputData element = new InputData();
					// tuple ID
					element.setTupleId((Integer.parseInt(resultId3Table
							.getString("tuple_id"))));

					// column A
					element.setColumnA(resultId3Table.getString("A"));

					// column B
					element.setColumnB(resultId3Table.getString("B"));

					// column C
					element.setColumnC(resultId3Table.getString("C"));

					// column D
					element.setColumnD(resultId3Table.getString("D"));

					// add element to array list
					dataObject.add(element);
				}
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		} catch (Exception exception) {
			System.out.println("Error in SQL ratings: " + exception);
		}

		try {
			resultId3Table.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// method to display data
	public void displayData(ArrayList<InputData> dataObject) {

		// column headers
		System.out.println("ID" + "\t" + "A" + "\t" + "B" + "\t" + "C" + "\t"
				+ "D");

		// display data
		for (InputData element : dataObject) {
			System.out.println(element.getTupleId() + "\t"
					+ element.getColumnA() + "\t" + element.getColumnB() + "\t"
					+ element.getColumnC() + "\t" + element.getColumnD());
		}
	}
}
