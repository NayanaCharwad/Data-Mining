/***********************************************************
#                   CSCI-B 565 DATA MINING
#                         Homework III
#                       Morning Class
#                    Computer Science Core
#                          Spring
#                     Indiana University,
#                       Bloomington, IN
#                       Nayana Charwad
#                    ncharwad@umail.iu.edu
#                       March 16 2015
#**********************************************************/
package id3classification;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class TreeNode {

	// name of the node
	String data;
	// probability in case of leaf nodes
	// float probability = 0;
	// store parent to calculate probability in case leaf is null
	TreeNode Parent;
	// subtree for storing individual attribute tress
	ArrayList<TreeNode> attributes = new ArrayList<TreeNode>();
	// String used to hold probability for parent node
	String parentProbability;
	// store entropy for the node for future calculation
	Float entropy;

	// getters and setters
	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public Float getEntropy() {
		return entropy;
	}

	public void setEntropy(Float entropy) {
		this.entropy = entropy;
	}

	/*
	 * public float getProbability() { return probability; }
	 * 
	 * public void setProbability(float probability) { this.probability =
	 * probability; }
	 */

	public TreeNode getParent() {
		return Parent;
	}

	public void setParent(TreeNode parent) {
		Parent = parent;
	}

	public ArrayList<TreeNode> getAttributes() {
		return attributes;
	}

	public void setAttributes(ArrayList<TreeNode> attributes) {
		this.attributes = attributes;
	}

	public String getParentProbability() {
		return parentProbability;
	}

	public void setParentProbability(String parentProbability) {
		this.parentProbability = parentProbability;
	}

	public TreeNode buildTree(ArrayList<String> buildTreeData,
			ArrayList<InputData> dataObject) {

		String[] inputAttributesTemp = null;
		ArrayList<String> inputAttributes = new ArrayList<String>();

		TreeNode root = null;
		int index = 0;

		// Split input file at spaces to get the corresponding set of attributes
		for (String inLine : buildTreeData) {
			if (index == 0) {
				index++;
				continue;
			} else
				inputAttributesTemp = inLine.split("\\s+");
		}

		for (String attribute : inputAttributesTemp) {
			inputAttributes.add(attribute);
		}

		ArrayList<String> data = new ArrayList<String>();

		// get corresponding attribute data
		if (inputAttributes.get(0).contains("A")) {
			for (InputData tempdata : dataObject) {
				if (!data.contains(tempdata.getColumnA()))
					data.add(tempdata.getColumnA());
			}
			// get corresponding attribute data
		} else if (inputAttributes.get(0).contains("B")) {
			for (InputData tempdata : dataObject) {
				if (!data.contains(tempdata.getColumnB()))
					data.add(tempdata.getColumnB());
			}
			// get corresponding attribute data
		} else if (inputAttributes.get(0).contains("C")) {
			for (InputData tempdata : dataObject) {
				if (!data.contains(tempdata.getColumnC()))
					data.add(tempdata.getColumnC());
			}
			// get corresponding attribute data
		} else if (inputAttributes.get(0).contains("D")) {
			for (InputData tempdata : dataObject) {
				if (!data.contains(tempdata.getColumnD()))
					data.add(tempdata.getColumnD());
			}
		}

		// formulate root node with initial attribute
		TreeNode temp = new TreeNode();
		temp.setData(inputAttributes.get(0));
		temp.setParent(null);
		// temp.setProbability(0);
		root = temp;

		for (String indata : data) {
			TreeNode node = new TreeNode();
			node.setData(indata);
			node.setParent(root);
			// node.setProbability(0);
			root.attributes.add(node);
		}

		computeEntropy(buildTreeData, dataObject, root);

		inputAttributes.remove(0);

		for (TreeNode child : root.getAttributes()) {
			ArrayList<String> featureList = new ArrayList<String>();

			for (String feature : inputAttributes)
				featureList.add(feature);

			if (child.getEntropy() != 0) {
				findAttachBestAttributeToSplit(buildTreeData, dataObject,
						child, featureList);
			}
		}

		return root;
	}

	public void findAttachBestAttributeToSplit(ArrayList<String> buildTreeData,
			ArrayList<InputData> dataObject, TreeNode root,
			ArrayList<String> featureList) {

		float minimumEntropy = 2;
		String bestFeature = "";
		TreeNode bestMatchNode = new TreeNode();

		for (String attribute : featureList) {
			ArrayList<String> data = new ArrayList<String>();

			// get corresponding attribute data
			if (attribute.contains("A")) {
				for (InputData tempdata : dataObject) {
					if (!data.contains(tempdata.getColumnA()))
						data.add(tempdata.getColumnA());
				}
				// get corresponding attribute data
			} else if (attribute.contains("B")) {
				for (InputData tempdata : dataObject) {
					if (!data.contains(tempdata.getColumnB()))
						data.add(tempdata.getColumnB());
				}
				// get corresponding attribute data
			} else if (attribute.contains("C")) {
				for (InputData tempdata : dataObject) {
					if (!data.contains(tempdata.getColumnC()))
						data.add(tempdata.getColumnC());
				}
				// get corresponding attribute data
			} else if (attribute.contains("D")) {
				for (InputData tempdata : dataObject) {
					if (!data.contains(tempdata.getColumnD()))
						data.add(tempdata.getColumnD());
				}
			}

			TreeNode temp = new TreeNode();
			temp.setData(attribute);
			temp.setParent(null);
			// temp.setProbability(0);

			for (String indata : data) {
				TreeNode node = new TreeNode();
				node.setData(indata);
				node.setParent(temp);
				// node.setProbability(0);
				temp.attributes.add(node);
			}

			temp.setParent(root);
			computeEntropy(buildTreeData, dataObject, temp);

			if (temp.getEntropy() < minimumEntropy) {
				ArrayList<TreeNode> bestMatchList = new ArrayList<TreeNode>();

				minimumEntropy = temp.getEntropy();
				bestMatchList.add(temp);
				root.setAttributes(bestMatchList);
				bestFeature = attribute;
				bestMatchNode = temp;
			}
		}

		featureList.remove(bestFeature);

		for (TreeNode node : bestMatchNode.getAttributes()) {

			if (node.getEntropy() != 0) {
				findAttachBestAttributeToSplit(buildTreeData, dataObject, node,
						featureList);
			}
		}
	}

	// compute probability for each node so as to return it whenever leaf node
	// does not exists or * is passed in input file
	public void computeEntropy(ArrayList<String> buildTreeData,
			ArrayList<InputData> dataObject, TreeNode root) {

		String classLabel = buildTreeData.get(0);
		TreeNode tempNode = new TreeNode();
		ArrayList<TreeNode> nodeList = new ArrayList<TreeNode>();
		Queue<TreeNode> treeQueue = new LinkedList<TreeNode>();
		// treeQueue.add(root);
		ArrayList<InputData> processData = new ArrayList<InputData>();
		float entropyParent = 0;
		int previousCount = 0;

		nodeList = root.getAttributes();

		if (!nodeList.isEmpty()) {
			for (TreeNode tnode : nodeList) {
				treeQueue.add(tnode);
			}
		}

		// find leaf nodes so as to add class labels
		while (!treeQueue.isEmpty()) {
			tempNode = treeQueue.remove();

			TreeNode bufferNode = new TreeNode();
			Stack<String> st = new Stack<String>();

			bufferNode = tempNode;
			// get the value of parent nodes to find out probability of each
			// node
			while (bufferNode != null) {
				st.push(bufferNode.getData());
				bufferNode = bufferNode.getParent();
			}

			processData = dataObject;

			while (!st.isEmpty()) {
				String value;
				String attribute = st.pop();
				ArrayList<InputData> temporaryData = new ArrayList<InputData>();

				previousCount = processData.size();

				if (st.isEmpty()) {
					break;
				} else {
					value = st.pop();
				}

				// get corresponding attribute data
				if (attribute.contains("A")) {
					for (InputData tempdata : processData) {
						if (tempdata.getColumnA().equals(value))
							temporaryData.add(tempdata);
					}
				} else if (attribute.contains("B")) {
					for (InputData tempdata : processData) {
						if (tempdata.getColumnB().equals(value))
							temporaryData.add(tempdata);
					}
				}
				if (attribute.contains("C")) {
					for (InputData tempdata : processData) {
						if (tempdata.getColumnC().equals(value))
							temporaryData.add(tempdata);
					}
				}
				if (attribute.contains("D")) {
					for (InputData tempdata : processData) {
						if (tempdata.getColumnD().equals(value))
							temporaryData.add(tempdata);
					}
				}

				processData = temporaryData;
			}

			ArrayList<ClassLabel> clist = new ArrayList<ClassLabel>();

			// get corresponding attribute data
			if (classLabel.contains("A")) {
				for (InputData tempdata : processData) {

					int flag = 0;
					// find if the class label is already in the list
					for (int i = 0; i < clist.size(); i++) {

						ClassLabel c1 = clist.get(i);

						if (c1.getValue().equals((tempdata.getColumnA()))) {
							flag = 1;
							c1.setCount(c1.getCount() + 1);
						}
						// Increment count if label is already in list
						clist.set(i, c1);
					}

					if (flag == 0) {
						ClassLabel cl = new ClassLabel();
						cl.setValue((tempdata.getColumnA()));
						cl.setCount(1);
						clist.add(cl);
					}
				}
			}

			// get corresponding attribute data
			if (classLabel.contains("B")) {
				for (InputData tempdata : processData) {

					int flag = 0;
					// find if the class label is already in the list
					for (int i = 0; i < clist.size(); i++) {

						ClassLabel c1 = clist.get(i);

						if (c1.getValue().equals((tempdata.getColumnB()))) {
							flag = 1;
							c1.setCount(c1.getCount() + 1);
						}
						// Increment count if label is already in list
						clist.set(i, c1);
					}

					if (flag == 0) {
						ClassLabel cl = new ClassLabel();
						cl.setValue((tempdata.getColumnB()));
						cl.setCount(1);
						clist.add(cl);
					}
				}
			}

			// get corresponding attribute data
			if (classLabel.contains("C")) {
				for (InputData tempdata : processData) {

					int flag = 0;
					// find if the class label is already in the list
					for (int i = 0; i < clist.size(); i++) {

						ClassLabel c1 = clist.get(i);

						if (c1.getValue().equals((tempdata.getColumnC()))) {
							flag = 1;
							c1.setCount(c1.getCount() + 1);
						}
						// Increment count if label is already in list
						clist.set(i, c1);
					}

					if (flag == 0) {
						ClassLabel cl = new ClassLabel();
						cl.setValue((tempdata.getColumnC()));
						cl.setCount(1);
						clist.add(cl);
					}
				}
			}

			// get corresponding attribute data
			if (classLabel.contains("D")) {
				for (InputData tempdata : processData) {

					int flag = 0;
					// find if the class label is already in the list
					for (int i = 0; i < clist.size(); i++) {

						ClassLabel c1 = clist.get(i);

						if (c1.getValue().equals((tempdata.getColumnD()))) {
							flag = 1;
							c1.setCount(c1.getCount() + 1);
						}
						// Increment count if label is already in list
						clist.set(i, c1);
					}

					if (flag == 0) {
						ClassLabel cl = new ClassLabel();
						cl.setValue((tempdata.getColumnD()));
						cl.setCount(1);
						clist.add(cl);
					}
				}
			}

			float entropy = 0;
			int countRecords = 0;

			// calculate entropy for each child node
			for (int i = 0; i < clist.size(); i++) {
				ClassLabel c1 = clist.get(i);
				// compute probability for each class
				float probabilityLabel = (float) c1.getCount()
						/ processData.size();
				float logValue = (float) (Math.log(probabilityLabel) / Math
						.log(2.0));
				countRecords = countRecords + c1.getCount();
				entropy = entropy - (probabilityLabel * logValue);
			}

			tempNode.setEntropy(entropy);

			entropyParent = entropyParent + (((float)countRecords / previousCount)* entropy);
		}

		root.setEntropy(entropyParent);
	}

	// compute probability for each node so as to return it whenever leaf node
	// does not exists or * is passed in input file
	public void computeNodeProbability(ArrayList<String> buildTreeData,
			ArrayList<InputData> dataObject, TreeNode root) {

		String classLabel = buildTreeData.get(0);
		TreeNode tempNode = new TreeNode();
		ArrayList<TreeNode> nodeList = new ArrayList<TreeNode>();
		Queue<TreeNode> treeQueue = new LinkedList<TreeNode>();
		treeQueue.add(root);
		ArrayList<InputData> processData = new ArrayList<InputData>();
		int index = 0;

		// find leaf nodes so as to add class labels
		while (!treeQueue.isEmpty()) {
			tempNode = treeQueue.remove();

			TreeNode bufferNode = new TreeNode();
			Stack<String> st = new Stack<String>();

			bufferNode = tempNode;
			// get the value of parent nodes to find out probability of each
			// node
			while (bufferNode != null) {
				st.push(bufferNode.getData());
				bufferNode = bufferNode.getParent();
			}

			processData = dataObject;

			if (index != 0) {

				while (!st.isEmpty()) {
					String value;
					String attribute = st.pop();
					ArrayList<InputData> temporaryData = new ArrayList<InputData>();

					if (st.isEmpty()) {
						break;
					} else {
						value = st.pop();
					}

					// get corresponding attribute data
					if (attribute.contains("A")) {
						for (InputData tempdata : processData) {
							if (tempdata.getColumnA().equals(value))
								temporaryData.add(tempdata);
						}
					} else if (attribute.contains("B")) {
						for (InputData tempdata : processData) {
							if (tempdata.getColumnB().equals(value))
								temporaryData.add(tempdata);
						}
					}
					if (attribute.contains("C")) {
						for (InputData tempdata : processData) {
							if (tempdata.getColumnC().equals(value))
								temporaryData.add(tempdata);
						}
					}
					if (attribute.contains("D")) {
						for (InputData tempdata : processData) {
							if (tempdata.getColumnD().equals(value))
								temporaryData.add(tempdata);
						}
					}

					processData = temporaryData;
				}
			}

			index++;
			ArrayList<ClassLabel> clist = new ArrayList<ClassLabel>();

			// get corresponding attribute data
			if (classLabel.contains("A")) {
				for (InputData tempdata : processData) {

					int flag = 0;
					// find if the class label is already in the list
					for (int i = 0; i < clist.size(); i++) {

						ClassLabel c1 = clist.get(i);

						if (c1.getValue().equals((tempdata.getColumnA()))) {
							flag = 1;
							c1.setCount(c1.getCount() + 1);
						}
						// Increment count if label is already in list
						clist.set(i, c1);
					}

					if (flag == 0) {
						ClassLabel cl = new ClassLabel();
						cl.setValue((tempdata.getColumnA()));
						cl.setCount(1);
						clist.add(cl);
					}
				}
			}

			// get corresponding attribute data
			if (classLabel.contains("B")) {
				for (InputData tempdata : processData) {

					int flag = 0;
					// find if the class label is already in the list
					for (int i = 0; i < clist.size(); i++) {

						ClassLabel c1 = clist.get(i);

						if (c1.getValue().equals((tempdata.getColumnB()))) {
							flag = 1;
							c1.setCount(c1.getCount() + 1);
						}
						// Increment count if label is already in list
						clist.set(i, c1);
					}

					if (flag == 0) {
						ClassLabel cl = new ClassLabel();
						cl.setValue((tempdata.getColumnB()));
						cl.setCount(1);
						clist.add(cl);
					}
				}
			}

			// get corresponding attribute data
			if (classLabel.contains("C")) {
				for (InputData tempdata : processData) {

					int flag = 0;
					// find if the class label is already in the list
					for (int i = 0; i < clist.size(); i++) {

						ClassLabel c1 = clist.get(i);

						if (c1.getValue().equals((tempdata.getColumnC()))) {
							flag = 1;
							c1.setCount(c1.getCount() + 1);
						}
						// Increment count if label is already in list
						clist.set(i, c1);
					}

					if (flag == 0) {
						ClassLabel cl = new ClassLabel();
						cl.setValue((tempdata.getColumnC()));
						cl.setCount(1);
						clist.add(cl);
					}
				}
			}

			// get corresponding attribute data
			if (classLabel.contains("D")) {
				for (InputData tempdata : processData) {

					int flag = 0;
					// find if the class label is already in the list
					for (int i = 0; i < clist.size(); i++) {

						ClassLabel c1 = clist.get(i);

						if (c1.getValue().equals((tempdata.getColumnD()))) {
							flag = 1;
							c1.setCount(c1.getCount() + 1);
						}
						// Increment count if label is already in list
						clist.set(i, c1);
					}

					if (flag == 0) {
						ClassLabel cl = new ClassLabel();
						cl.setValue((tempdata.getColumnD()));
						cl.setCount(1);
						clist.add(cl);
					}
				}
			}

			String outputLine = " ";
			for (int i = 0; i < clist.size(); i++) {
				ClassLabel c1 = clist.get(i);
				// compute probability for each class
				float probabilityLabel = (float) c1.getCount()
						/ processData.size();
				c1.setProbability(probabilityLabel);
				clist.set(i, c1);
				outputLine = outputLine + "Label" + " " + c1.getValue() + " "
						+ "Probability" + " "
						+ Float.toString(c1.getProbability()) + "\t";
			}

			if (clist.size() == 0)
				outputLine = "null";

			// assign probability values to parent nodes
			tempNode.setParentProbability(outputLine);
			System.out.println("Node" + "\t" + tempNode.getData() + "\t"
					+ "output" + "\t" + outputLine);

			nodeList = tempNode.getAttributes();

			if (!nodeList.isEmpty()) {
				for (TreeNode tnode : nodeList) {
					treeQueue.add(tnode);
				}
			}
		}
	}

	public void searchTree(ArrayList<String> InputUserData,
			ArrayList<String> outputData, TreeNode root) {

		String[] inputAttributes = null;

		// Split input file at spaces to get the corresponding set of attributes
		for (String inLine : InputUserData) {

			// get input attributes line by line
			inputAttributes = inLine.split("\\s+");

			TreeNode tempNode = root;
			String outputLine = " ";
			outputLine = tempNode.getParentProbability();

			// search the leaf node for class attributes based on input data
			for (String searchTerm : inputAttributes) {
				for (TreeNode tNode : tempNode.getAttributes()) {
					if (tNode.getData().equals(searchTerm)) {
						tempNode = tNode;

						if (!tempNode.getParentProbability().equals("null")) {
							outputLine = tempNode.getParentProbability();
						}
						break;
					}
				}
				// get the label node for next attribute
				if (!tempNode.getAttributes().isEmpty())
					tempNode = tempNode.getAttributes().get(0);
			}

			// String outputLine;
			// write output class labels and probability to output files
			// for (TreeNode tNode : tempNode.getAttributes()) {
			// outputLine = "Label" + tempNode.getData() + "\t" + "Probability"
			// + tempNode.getParentProbability() + "\t";
			outputData.add("User Input : " + inLine);
			outputData.add("Class : " + outputLine);
			outputData
					.add("----------------------------------------------------------------------------------------------------");
			// }
		}
	}
}
