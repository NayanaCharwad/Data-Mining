/***********************************************************
#                   CSCI-B 565 DATA MINING
#                         Homework III
#                       Morning Class
#                    Computer Science Core
#                          Spring
#                     Indiana University,
#                       Bloomington, IN
#                       Nayana Charwad
#                    ncharwad@umail.iu.edu
#                       March 16 2015
#**********************************************************/
package id3classification;

public class ClassLabel {

	String value;
	int count = 0;
	float probability = 0;

	public float getProbability() {
		return probability;
	}

	public void setProbability(float probability) {
		this.probability = probability;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
}
