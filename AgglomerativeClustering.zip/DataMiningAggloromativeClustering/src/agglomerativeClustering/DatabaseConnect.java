//Author : Nayana Charwad (ncharwad)

package agglomerativeClustering;

import java.sql.*;

import java.util.ArrayList;

public class DatabaseConnect {

	private Connection connect;
	private Statement statement;
	private ResultSet resultRatings, resultMovies, resultUsers,
			resultOccupation;

	public DatabaseConnect() {

		try {
			Class.forName("com.mysql.jdbc.Driver");

			connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/b565_assignment2", "root",
					"root");

			statement = connect.createStatement();

		} catch (Exception exception) {
			System.out.println("Error while connection:" + exception);
		}
	}

	public void fetchData(ArrayList<MergedData> dataObject) {

		int i = 0;
		// fetch data from ratings table
		try {
			String queryRatings = "Select * from ratings";
			resultRatings = statement.executeQuery(queryRatings);

			// Formulate composite data object from all 3 tables so as to
			// process the objects as clusters in whole
			try {
				while (resultRatings.next() && i < 6000) {
					MergedData element = new MergedData();
					if (i > 3999) {
						element.setUser_id(Integer.parseInt(resultRatings
								.getString("user_id")));
						element.setMovie_id(Integer.parseInt(resultRatings
								.getString("movie_id")));
						element.setRatings(Integer.parseInt(resultRatings
								.getString("ratings")));
						dataObject.add(element);
					}
					i++;
				}

				System.out.println("Ratings Downloaded : " + "\t"
						+ dataObject.size() + "\n\n");
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		} catch (Exception exception) {
			System.out.println("Error in SQL ratings: " + exception);
		}

		try {
			resultRatings.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// fetch data from movies table
		try {
			String queryMovies = "Select * from movies";
			resultMovies = statement.executeQuery(queryMovies);
		} catch (Exception exception) {
			System.out.println("Error in SQL movies: " + exception);
		}

		try {

			// get respective elements from user table
			for (MergedData element : dataObject) {

				resultMovies.first();
				do {
					String[] genreArray = new String[5];
					MergedData tempElement = new MergedData();

					tempElement.setMovie_id(Integer.parseInt(resultMovies
							.getString("movie_id")));
					if (element.getMovie_id() == tempElement.getMovie_id()) {

						element.setMovie_name(resultMovies.getString("name"));

						genreArray[0] = resultMovies.getString("genre1");
						genreArray[1] = resultMovies.getString("genre2");
						genreArray[2] = resultMovies.getString("genre3");
						genreArray[3] = resultMovies.getString("genre4");
						genreArray[4] = resultMovies.getString("genre5");

						element.setGenre(genreArray);
						break;
					}
				} while (resultMovies.next());

				/*
				 * System.out.println(element.user_id + "\t" + element.movie_id
				 * + "\t" + element.ratings + "\t" + element.movie_name);
				 */
			}
		} catch (NumberFormatException | SQLException e1) {
			e1.printStackTrace();
		}

		try {
			System.out.println("Movies table downloaded !!");
			resultMovies.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// fetch data from users table
		try {
			String queryUsers = "Select * from users";
			resultUsers = statement.executeQuery(queryUsers);
		} catch (Exception exception) {
			System.out.println("Error in SQL users: " + exception);
		}

		// get respective elements from user table
		for (MergedData element : dataObject) {
			try {
				resultUsers.first();
				do {
					MergedData tempElement = new MergedData();
					tempElement.setUser_id(Integer.parseInt(resultUsers
							.getString("user_id")));
					if (element.getUser_id() == tempElement.getUser_id()) {

						element.setGender(resultUsers.getString("gender")
								.charAt(0));
						element.setAge(Integer.parseInt(resultUsers
								.getString("age")));
						element.setOccupation(Integer.parseInt(resultUsers
								.getString("occupation")));
						break;
					}
				} while (resultUsers.next());
			} catch (NumberFormatException | SQLException e) {
				e.printStackTrace();
			}
		}
		try {
			System.out.println("Users table downloaded !!");
			resultUsers.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// fetch data from occupation table
		try {
			String queryOccupation = "Select * from occupation";
			resultOccupation = statement.executeQuery(queryOccupation);
		} catch (Exception exception) {
			System.out.println("Error in SQL occupation: " + exception);
		}

		for (MergedData element : dataObject) {
			try {
				resultOccupation.first();
				do {
					MergedData tempElement = new MergedData();
					tempElement.setOccupation(Integer.parseInt(resultOccupation
							.getString("occupation_id")));
					if (element.getOccupation() == tempElement.getOccupation()) {
						element.setOccupationDescription(resultOccupation
								.getString("description"));
						break;
					}
				} while (resultOccupation.next());
			} catch (NumberFormatException | SQLException e) {
				e.printStackTrace();
			}
		}

		try {
			System.out.println("Occupation table downloaded !!\n\n");
			resultOccupation.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void displayData(ArrayList<MergedData> dataObject) {

		System.out.println("User ID" + "\t" + "Gender" + "\t" + "Age" + "\t"
				+ "Occ ID" + "\t" + "Occupation" + "\t" + "Movie Id" + "\t"
				+ "Rating" + "\t\t" + "Movie Name" + "\n");

		for (MergedData element : dataObject) {
			System.out.println(element.user_id + "\t" + element.gender + "\t"
					+ element.age + "\t" + element.occupation + "\t"
					+ element.occupationDescription + "\t" + element.movie_id
					+ "\t\t" + element.ratings + "\t" + element.movie_name);
		}
	}
}
