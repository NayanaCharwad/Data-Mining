//Author : Nayana Charwad (ncharwad)
package agglomerativeClustering;

import java.util.ArrayList;

public class Cluster {

	ArrayList<MergedData> itemList = new ArrayList<MergedData>();

	public ArrayList<MergedData> getItemList() {
		return itemList;
	}

	public void setItemList(ArrayList<MergedData> itemList) {
		this.itemList = itemList;
	}

	public double calculateMinimumDistance(Cluster compare, int algorithmType,FilledDistanceMatrix distanceMat) {
		double distance = 0;
		double minimumDistance = 0;
		int counter = 0;

		// calculate minimum distance between two clusters
		for (MergedData firstData : this.itemList) {
			for (MergedData secondData : this.itemList) {
				distance = firstData.calculateMinimumDistance(secondData,distanceMat);

				// average linkage
				if (algorithmType == 3) {
					minimumDistance = distance + minimumDistance;
					counter++;
				}
				// single linkage
				else if (algorithmType == 1) {
					// store initial clusters at start and iterate to find
					// minimum distance
					if (minimumDistance == -1) {
						minimumDistance = distance;
					}
					// store minimum distance
					else if (distance < minimumDistance) {
						minimumDistance = distance;
					}
				}
				// complete linkage
				else if (algorithmType == 2) {
					// store initial clusters at start and iterate to find
					// maximum distance
					if (minimumDistance == -1) {
						minimumDistance = distance;
					}
					// store maximum distance
					else if (distance > minimumDistance) {
						minimumDistance = distance;
					}
				}
			}
		}

		// calculate average distance between two clusters
		if (algorithmType == 3) {
			minimumDistance = minimumDistance / counter;
		}

		return minimumDistance;
	}
}
