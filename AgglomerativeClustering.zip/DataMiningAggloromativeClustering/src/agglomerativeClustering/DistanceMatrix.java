//Author : Nayana Charwad (ncharwad)

package agglomerativeClustering;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class DistanceMatrix {

	int node1;
	int node2;
	double distance;

	public int getNode1() {
		return node1;
	}

	public void setNode1(int node1) {
		this.node1 = node1;
	}

	public int getNode2() {
		return node2;
	}

	public void setNode2(int node2) {
		this.node2 = node2;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public void setData(int node1, int node2, double distance) {
		this.setNode1(node1);
		this.setNode2(node2);
		this.setDistance(distance);
	}

	public void fillDistanceAge(ArrayList<DistanceMatrix> distanceAge) {
		FileReader fread = null;
		try {
			fread = new FileReader(
					"C:\\Users\\Nayana\\Desktop\\AgeDistance.csv");
			BufferedReader fbuffer = new BufferedReader(fread);
			String inputLine;
			String splitByComma = ",";
			try {
				while ((inputLine = fbuffer.readLine()) != null) {
					if (inputLine.length() > 0) {
						String[] entry = inputLine.split(splitByComma);
						DistanceMatrix matrix = new DistanceMatrix();

						matrix.setNode1(Integer.parseInt(entry[0]));
						matrix.setNode2(Integer.parseInt(entry[1]));
						matrix.setDistance(Double.parseDouble(entry[2]));

						distanceAge.add(matrix);
					}
				}
				fbuffer.close();
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void fillDistanceRatings(ArrayList<DistanceMatrix> distanceRatings) {
		FileReader fread = null;
		try {
			fread = new FileReader(
					"C:\\Users\\Nayana\\Desktop\\RatingsDistance.csv");
			BufferedReader fbuffer = new BufferedReader(fread);
			String inputLine;
			String splitByComma = ",";
			try {
				while ((inputLine = fbuffer.readLine()) != null) {
					if (inputLine.length() > 0) {
						String[] entry = inputLine.split(splitByComma);
						DistanceMatrix matrix = new DistanceMatrix();

						matrix.setNode1(Integer.parseInt(entry[0]));
						matrix.setNode2(Integer.parseInt(entry[1]));
						matrix.setDistance(Double.parseDouble(entry[2]));

						distanceRatings.add(matrix);
					}
				}
				fbuffer.close();
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
