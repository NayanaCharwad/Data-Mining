//Author : Nayana Charwad (ncharwad)

package agglomerativeClustering;

import java.io.*;
import java.util.ArrayList;

/**
 * @author Nayana
 *
 */
/**
 * @author Nayana
 *
 */
public class MergedData {

	int user_id;
	int movie_id;
	int ratings;
	String movie_name;
	String[] genre = new String[5];
	char gender;
	int age;
	int occupation;
	String occupationDescription;
	
	/**
	 * @return
	 */
	public int getUser_id() {
		return user_id;
	}

	/**
	 * @param user_id
	 */
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	/**
	 * @return
	 */
	public int getMovie_id() {
		return movie_id;
	}

	/**
	 * @param movie_id
	 */
	public void setMovie_id(int movie_id) {
		this.movie_id = movie_id;
	}

	/**
	 * @return
	 */
	public int getRatings() {
		return ratings;
	}

	/**
	 * @param ratings
	 */
	public void setRatings(int ratings) {
		this.ratings = ratings;
	}

	/**
	 * @return
	 */
	public String getMovie_name() {
		return movie_name;
	}

	/**
	 * @param movie_name
	 */
	public void setMovie_name(String movie_name) {
		this.movie_name = movie_name;
	}

	/**
	 * @return
	 */
	public String[] getGenre() {
		return genre;
	}

	/**
	 * @param genre
	 */
	public void setGenre(String[] genre) {
		this.genre = genre;
	}

	/**
	 * @return
	 */
	public char getGender() {
		return gender;
	}

	/**
	 * @param gender
	 */
	public void setGender(char gender) {
		this.gender = gender;
	}

	/**
	 * @return
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @param age
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * @return
	 */
	public int getOccupation() {
		return occupation;
	}

	/**
	 * @param occupation
	 */
	public void setOccupation(int occupation) {
		this.occupation = occupation;
	}

	/**
	 * @return
	 */
	public String getOccupationDescription() {
		return occupationDescription;
	}

	/**
	 * @param occupationDescription
	 */
	public void setOccupationDescription(String occupationDescription) {
		this.occupationDescription = occupationDescription;
	}

	public double calculateMinimumDistance(MergedData compare,FilledDistanceMatrix distanceMat) {
		double distance = 0;

		//distance = (this.calculateAgeDistance(compare,distanceMat))
			//	+ (this.calculateOccupationDistance(compare,distanceMat));

		distance = (this.calculateRatingsDistance(compare,distanceMat))
				+ (this.calculateGenreDistance(compare,distanceMat));
	
		return distance;
	}

	public double calculateAgeDistance(MergedData compare,FilledDistanceMatrix distanceMat) {
		double tempDistance = 0;

		for (DistanceMatrix element : distanceMat.distanceAge) {
			if ((element.getNode1() == this.getAge())
					&& (element.getNode2() == compare.getAge())) {
				tempDistance = element.getDistance();
				break;
			}
		}
		return tempDistance;
	}

	public double calculateOccupationDistance(MergedData compare,FilledDistanceMatrix distanceMat) {
		double tempDistance = 0;
		int flag = 0, flag1 = 0;

		for (DistanceMatrixString element : distanceMat.distanceOccupation) {
			flag = 0;
			flag1 = 0;
			for (String occupation : element.getSimilar()) {
				if (occupation.equals(this.getOccupationDescription()))
					flag = 1;
				if (occupation.equals(compare.getOccupationDescription()))
					flag1 = 1;
			}

			if (flag == 1 && flag1 == 1) {
				tempDistance = element.getDistance();
				break;
			}
		}

		if(flag == 1 && flag1 == 1)
		{
			flag = 1;
		}
		else
		{
			tempDistance = 0.6;
		}

		return tempDistance;
	}

	public double calculateGenreDistance(MergedData compare,FilledDistanceMatrix distanceMat) {
		double tempDistance = 0;
		int flag = 0, flag1 = 0;

		for (DistanceMatrixString element : distanceMat.distanceGenre) {
			flag = 0;
			flag1 = 0;
			
			for (String genre : element.getSimilar()) {

				for (String thisGenre : this.getGenre()) {
					if (genre.equals(thisGenre))
						flag = 1;
				}

				for (String compareGenre : compare.getGenre()) {
					if (genre.equals(compareGenre))
						flag1 = 1;
				}
			}

			if (flag == 1 && flag1 == 1) {
				tempDistance = element.getDistance();
				break;
			}
		}
		
		if(flag == 1 && flag1 == 1)
		{
			flag = 1;
		}
		else
		{
			tempDistance = 0.4;
		}

		return tempDistance;

	}

	public double calculateRatingsDistance(MergedData compare,FilledDistanceMatrix distanceMat) {
		double tempDistance = 0;

		for (DistanceMatrix element : distanceMat.distanceRatings) {
			if ((element.getNode1() == this.getRatings())
					&& (element.getNode2() == compare.getRatings())) {
				tempDistance = element.getDistance();
				break;
			}
		}
		return tempDistance;
	}

}