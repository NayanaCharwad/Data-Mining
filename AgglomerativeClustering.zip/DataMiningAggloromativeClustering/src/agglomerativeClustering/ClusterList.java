//Author : Nayana Charwad (ncharwad)

package agglomerativeClustering;

import java.io.*;
import java.util.ArrayList;

public class ClusterList {

	ArrayList<Cluster> individualClusterList = new ArrayList<Cluster>();
	Cluster firstCluster = new Cluster();
	Cluster secondCluster = new Cluster();
	Cluster merged = new Cluster();

	public ClusterList(ArrayList<MergedData> dataObject) {
		// each item is considered as individual cluster at start
		for (MergedData element : dataObject) {
			Cluster tempCluster = new Cluster();
			tempCluster.itemList.add(element);
			this.individualClusterList.add(tempCluster);
		}
	}

	public Cluster getMerged() {
		return merged;
	}

	public void setMerged(Cluster merged) {
		this.merged = merged;
	}

	public ArrayList<Cluster> getIndividualClusterList() {
		return individualClusterList;
	}

	public void setIndividualClusterList(
			ArrayList<Cluster> individualClusterList) {
		this.individualClusterList = individualClusterList;
	}

	public Cluster getFirstCluster() {
		return firstCluster;
	}

	public void setFirstCluster(Cluster firstCluster) {
		this.firstCluster = firstCluster;
	}

	public Cluster getSecondCluster() {
		return secondCluster;
	}

	public void setSecondCluster(Cluster secondCluster) {
		this.secondCluster = secondCluster;
	}

	public ArrayList<Cluster> getList() {
		return individualClusterList;
	}

	public void setList(ArrayList<Cluster> list) {
		this.individualClusterList = list;
	}

	public void findClosestClusters(int algorithmType,FilledDistanceMatrix distanceMat) {
		double distance = 0;
		double minimumDistance = -1;

		// calculate minimum distance between two clusters
		for (int firstIndex = 0; firstIndex < this.individualClusterList.size(); firstIndex++) {
			Cluster firstCluster = this.individualClusterList.get(firstIndex);
			for (int secondIndex = firstIndex + 1; secondIndex < this.individualClusterList
					.size(); secondIndex++) {
				Cluster secondCluster = this.individualClusterList
						.get(secondIndex);
				distance = firstCluster.calculateMinimumDistance(secondCluster,algorithmType,distanceMat);

				// System.out.println("Distance:" + distance + "First:" +
				// firstIndex + "Second:" +secondIndex);
				// store initial clusters at start and iterate to find minimum
				// distance
				if (minimumDistance == -1) {
					minimumDistance = distance;
					this.setFirstCluster(firstCluster);
					this.setSecondCluster(secondCluster);
		//			System.out.println("Distance:" + distance + "First:"
		//					+ firstIndex + "Second:" + secondIndex);
				}
				// store minimum distance
				else if (distance < minimumDistance) {
					minimumDistance = distance;
					this.setFirstCluster(firstCluster);
					this.setSecondCluster(secondCluster);
			//		System.out.println("Merged Distance:" + distance + "First:"
			//				+ firstIndex + "Second:" + secondIndex);
				}
			}
		}
	}

	public void mergeClosestClusters() {

		Cluster tempMerged = new Cluster();

		// copy first cluster items
		for (MergedData items : this.getFirstCluster().itemList) {
			tempMerged.itemList.add(items);
		}
		// copy second cluster items
		for (MergedData items : this.getSecondCluster().itemList) {
			tempMerged.itemList.add(items);
		}

		this.setMerged(tempMerged);
	}

	public void addMergedCluster() {
		this.individualClusterList.add(getMerged());
	}

	public void removePairClusters() {
		this.individualClusterList.remove(getFirstCluster());
		this.individualClusterList.remove(getSecondCluster());
	}

	public int returnSize() {
		return this.individualClusterList.size();
	}

	public void writeClusterData() {
		FileWriter fwrite;
		int counter;
		
		try {
			fwrite = new FileWriter("C:\\Users\\Nayana\\Desktop\\Output.csv");

			PrintWriter fout = new PrintWriter(fwrite);
			{
				for (Cluster tempCluster : this.individualClusterList) {
					fout.println();
					fout.println("---------------------------------------------------------------New Cluster------------------------------------------------");
					fout.println();
					for (MergedData element : tempCluster.itemList) {
						fout.write(element.user_id + "," + element.gender + ","
								+ element.age + "," + element.occupation + ","
								+ element.occupationDescription + ","
								+ element.movie_id + "," + element.ratings
								+ "," + element.movie_name + ",");
						counter = 0;
						for (String genre : element.getGenre()) {
							
							if (!genre.isEmpty())
								fout.write(genre);
							else
								fout.write("NULL");
							counter++;	
							
							if(counter < 5)
								fout.write(",");
							
						}
						fout.println();
					}
				}

			}

			fout.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("Data written to output file");
	}

}
