//Author : Nayana Charwad (ncharwad)

package agglomerativeClustering;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class FilledDistanceMatrix {
	
	// distance matrices
		ArrayList<DistanceMatrix> distanceAge = new ArrayList<DistanceMatrix>();
		ArrayList<DistanceMatrixString> distanceOccupation = new ArrayList<DistanceMatrixString>();
		ArrayList<DistanceMatrixString> distanceGenre = new ArrayList<DistanceMatrixString>();
		ArrayList<DistanceMatrix> distanceRatings = new ArrayList<DistanceMatrix>();
		
		
		public FilledDistanceMatrix() {
			this.fillDistanceAge();
			this.fillDistanceOccupation();
			this.fillDistanceGenre();
			this.fillDistanceRatings();
		}

		public void fillDistanceAge() {
			FileReader fread = null;
			try {
				fread = new FileReader(
						"C:\\Users\\Nayana\\Desktop\\AgeDistance.csv");
				BufferedReader fbuffer = new BufferedReader(fread);
				String inputLine;
				String splitByComma = ",";
				try {
					while ((inputLine = fbuffer.readLine()) != null) {
						if (inputLine.length() > 0) {
							String[] entry = inputLine.split(splitByComma);
							DistanceMatrix matrix = new DistanceMatrix();

							matrix.setNode1(Integer.parseInt(entry[0]));
							matrix.setNode2(Integer.parseInt(entry[1]));
							matrix.setDistance(Double.parseDouble(entry[2]));

							distanceAge.add(matrix);
						}
					}
					fbuffer.close();
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}

		public void fillDistanceOccupation() {
			FileReader fread = null;
			try {
				fread = new FileReader(
						"C:\\Users\\Nayana\\Desktop\\OccupationDistance.csv");
				BufferedReader fbuffer = new BufferedReader(fread);
				String inputLine;
				String splitByComma = ",";
				try {
					while ((inputLine = fbuffer.readLine()) != null) {
						if (inputLine.length() > 0) {
							String[] entry = inputLine.split(splitByComma);
							DistanceMatrixString matrix = new DistanceMatrixString();
							matrix.setSimilar(entry);
							matrix.setDistance(Double.parseDouble(entry[0]));
							distanceOccupation.add(matrix);
						}
					}
					fbuffer.close();
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}

		public void fillDistanceGenre() {
			FileReader fread = null;
			try {
				fread = new FileReader(
						"C:\\Users\\Nayana\\Desktop\\GenreDistance.csv");
				BufferedReader fbuffer = new BufferedReader(fread);
				String inputLine;
				String splitByComma = ",";
				try {
					while ((inputLine = fbuffer.readLine()) != null) {
						if (inputLine.length() > 0) {
							String[] entry = inputLine.split(splitByComma);
							DistanceMatrixString matrix = new DistanceMatrixString();
							matrix.setSimilar(entry);
							matrix.setDistance(Double.parseDouble(entry[0]));
							distanceGenre.add(matrix);
						}
					}
					fbuffer.close();
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}

		public void fillDistanceRatings() {
			FileReader fread = null;
			try {
				fread = new FileReader(
						"C:\\Users\\Nayana\\Desktop\\RatingsDistance.csv");
				BufferedReader fbuffer = new BufferedReader(fread);
				String inputLine;
				String splitByComma = ",";
				try {
					while ((inputLine = fbuffer.readLine()) != null) {
						if (inputLine.length() > 0) {
							String[] entry = inputLine.split(splitByComma);
							DistanceMatrix matrix = new DistanceMatrix();

							matrix.setNode1(Integer.parseInt(entry[0]));
							matrix.setNode2(Integer.parseInt(entry[1]));
							matrix.setDistance(Double.parseDouble(entry[2]));

							distanceRatings.add(matrix);
						}
					}
					fbuffer.close();
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

}
