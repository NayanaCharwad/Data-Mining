//Author : Nayana Charwad (ncharwad)

package agglomerativeClustering;

public class DistanceMatrixString {

	String[] similar;
	double distance;
	
	public String[] getSimilar() {
		return similar;
	}
	public void setSimilar(String[] similar) {
		this.similar = similar;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	
}
