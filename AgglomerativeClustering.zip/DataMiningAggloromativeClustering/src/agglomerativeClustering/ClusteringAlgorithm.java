//Author : Nayana Charwad (ncharwad)

package agglomerativeClustering;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class ClusteringAlgorithm {

	public static void main(String[] args) {

		ArrayList<MergedData> dataObject = new ArrayList<MergedData>();

		DatabaseConnect dbConnect = new DatabaseConnect();
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		int algorithmType = 3;
		
		System.out.println("Agglomerative Clustering Type");
		System.out.println("1: Single Linkage");
		System.out.println("2: Complete Linkage");
		System.out.println("3: Average Linkage");
		System.out.println("Enter your choice : ");
		
		try {
			algorithmType = Integer.parseInt(in.readLine());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// get data from database and pre process data so as to form merged
		// items
		dbConnect.fetchData(dataObject);

		// display data
	//	dbConnect.displayData(dataObject);

		// define cluster
		ClusterList allClusters = new ClusterList(dataObject);

		//fill distance matrix for all parameters
		FilledDistanceMatrix distance = new FilledDistanceMatrix();
		
		// Merge clusters based on minimum distance between them
		while (allClusters.returnSize() > 5) {
			
			if (allClusters.returnSize()%50 == 0)
			{
				System.out.println("Merging Clusters" + "\t" + allClusters.returnSize());
			}
			
			// find two closest clusters
			allClusters.findClosestClusters(algorithmType,distance);

			// merge two closest clusters
			allClusters.mergeClosestClusters();

			// delete the old clusters and add new merged cluster to the list
			allClusters.addMergedCluster();
			allClusters.removePairClusters();
		}

		// write the clustered records to output file for further analysis
		allClusters.writeClusterData();

	}

}
