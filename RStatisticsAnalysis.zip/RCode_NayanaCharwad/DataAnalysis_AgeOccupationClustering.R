#Author : Nayana Charwad (ncharwad)

split.screen(c(2, 1)) 

#Load dataset
dataset1 <- read.table("C:\\Users\\Nayana\\Desktop\\Cluster1_AgeOccupation.csv",header=F,sep=",",fill = TRUE)

str(dataset1)

summary(dataset1$V5)

summary(dataset1$V7)

hist(dataset1$V7,main="Cluster1 : Distribution based on ratings",xlab="Ratings")

screen(1)
hist(dataset1$V3,main="Cluster1 : Distribution based on age",xlab="Age")

boxplot(V3~V5,data=dataset1,main="Cluster1 : Plot of occupation and age",xlab="Occupation",ylab="Age")

plot(V7~V11,data=dataset1,main="Cluster1 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V12,data=dataset1,main="Cluster1 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V13,data=dataset1,main="Cluster1 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V14,data=dataset1,main="Cluster1 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

boxplot(dataset1$V7~dataset1$V3,main="Cluster1 : Boxplot of age and ratings",xlab="Age",ylab="Ratings")

boxplot(dataset1$V3~dataset1$V11,main="Cluster1 : Boxplot of genre and age",xlab="Genre",ylab="Age")

boxplot(dataset1$V7~dataset1$V11,main="Cluster1 : Boxplot of genre and ratings",xlab="Genre",ylab="Ratings")

boxplot(dataset1$V7~dataset1$V5,main="Cluster1 : Boxplot of occupation and ratings",xlab="Occupation",ylab="Ratings")


#Load dataset
dataset2 <- read.table("C:\\Users\\Nayana\\Desktop\\Cluster2_AgeOccupation.csv",header=F,sep=",",fill = TRUE)

str(dataset2)

summary(dataset2)

summary(dataset2$V5)

summary(dataset2$V7)

hist(dataset2$V7,main="Cluster2 : Distribution based on ratings",xlab="Ratings")

screen(2)
hist(dataset2$V3,main="Cluster2 : Distribution based on age",xlab="Age")

boxplot(V3~V5,data=dataset2,main="Cluster2 : Plot of occupation and age",xlab="Occupation",ylab="Age")


plot(V7~V11,data=dataset2,main="Cluster2 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V12,data=dataset2,main="Cluster2 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V13,data=dataset2,main="Cluster2 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V14,data=dataset2,main="Cluster2 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

boxplot(dataset2$V7~dataset2$V3,main="Cluster2 : Boxplot of age and ratings",xlab="Age",ylab="Ratings")

boxplot(dataset2$V3~dataset2$V13,main="Cluster2 : Boxplot of genre and age",xlab="Genre",ylab="Age")

boxplot(dataset2$V7~dataset2$V13,main="Cluster2 : Boxplot of genre and ratings",xlab="Genre",ylab="Ratings")

boxplot(dataset2$V7~dataset2$V5,main="Cluster2 : Boxplot of occupation and ratings",xlab="Occupation",ylab="Ratings")


#Load dataset
dataset3 <- read.table("C:\\Users\\Nayana\\Desktop\\Cluster3_AgeOccupation.csv",header=F,sep=",",fill = TRUE)

str(dataset3)

summary(dataset3)

summary(dataset3$V5)

hist(dataset3$V7,main="Cluster3 : Distribution based on ratings",xlab="Ratings")

boxplot(V3~V5,data=dataset3,main="Cluster3 : Plot of occupation and age",xlab="Occupation",ylab="Age")

screen(1)
hist(dataset3$V3,main="Cluster3 : Distribution based on age",xlab="Age")

plot(V7~V11,data=dataset3,main="Cluster3 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V12,data=dataset3,main="Cluster3 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V13,data=dataset3,main="Cluster3 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V14,data=dataset3,main="Cluster3 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

boxplot(dataset3$V7~dataset3$V3,main="Cluster3 : Boxplot of age and ratings",xlab="Age",ylab="Ratings")

boxplot(dataset3$V3~dataset3$V12,main="Cluster3 : Boxplot of genre and age",xlab="Genre",ylab="Ratings")

boxplot(dataset3$V7~dataset3$V12,main="Cluster3 : Boxplot of genre and ratings",xlab="Genre",ylab="Ratings")

boxplot(dataset3$V7~dataset3$V5,main="Cluster3 : Boxplot of occupation and ratings",xlab="Occupation",ylab="Ratings")


#Load dataset
dataset4 <- read.table("C:\\Users\\Nayana\\Desktop\\Cluster5_AgeOccupation.csv",header=F,sep=",",fill = TRUE)

str(dataset4)

summary(dataset4)

summary(dataset4$V5)

hist(dataset4$V7,main="Cluster4 : Distribution based on ratings",xlab="Ratings")

screen(2)
hist(dataset4$V3,main="Cluster4 : Distribution based on age",xlab="Age")

boxplot(V3~V5,data=dataset4,main="Cluster4 : Plot of occupation and age",xlab="Occupation",ylab="Age")

plot(V7~V11,data=dataset4,main="Cluster4 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V12,data=dataset4,main="Cluster4 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V13,data=dataset4,main="Cluster4 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V14,data=dataset4,main="Cluster4 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

boxplot(dataset4$V7~dataset4$V3,main="Cluster4 : Boxplot of age and ratings",xlab="Age",ylab="Ratings")

boxplot(dataset4$V3~dataset4$V12,main="Cluster4 : Boxplot of genre and age",xlab="Genre",ylab="Ratings")

boxplot(dataset4$V7~dataset4$V12,main="Cluster4 : Boxplot of genre and ratings",xlab="Genre",ylab="Ratings")

boxplot(dataset4$V7~dataset4$V5,main="Cluster1 : Boxplot of occupation and ratings",xlab="Occupation",ylab="Ratings")


#Load dataset
dataset5 <- read.table("C:\\Users\\Nayana\\Desktop\\Cluster4_AgeOccupation.csv",header=F,sep=",",fill = TRUE)

str(dataset5)

summary(dataset5)

hist(dataset4$V7,main="Cluster5 : Distribution based on ratings",xlab="Ratings")

screen(2)
hist(dataset4$V3,main="Cluster5 : Distribution based on age",xlab="Age")

plot(V7~V11,data=dataset5,main="Cluster4 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V12,data=dataset5,main="Cluster4 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V13,data=dataset5,main="Cluster4 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

plot(V7~V14,data=dataset5,main="Cluster4 : Plot of genre and ratings",xlab="Genre",ylab="Ratings")

boxplot(dataset$V7~dataset4$V3,main="Cluster5 : Boxplot of age and ratings",xlab="Age",ylab="Ratings")

boxplot(dataset$V3~dataset4$V11,main="Cluster5 : Boxplot of genre and age",xlab="Genre",ylab="Ratings")

boxplot(dataset$V7~dataset4$V11,main="Cluster5 : Boxplot of genre and ratings",xlab="Genre",ylab="Ratings")



