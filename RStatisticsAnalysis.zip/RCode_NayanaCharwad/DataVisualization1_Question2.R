//Author : Nayana Charwad (ncharwad)

library(RMySQL)

mydb = dbConnect(MySQL(), user = "root", password = "root", dbname = "b565_assignment2", host = "localhost")

dbListTables(mydb)

dbListFields(mydb, "veh_pri")

rs = dbSendQuery(mydb,"select * from veh_pri")

rs

dataset = fetch(rs,n=-1)

dataset

split.screen(c(2,1))

#price      
screen(1)
hist(dataset$price,main="Histogram for distribution of vehicle price",xlab="price")

#mileage    
screen(2)
hist(dataset$mileage,main="Histogram for distribution of vehicle mileage",xlab="mileage")

#cylinders  
screen(1)
hist(dataset$cylinders,,main="Histogram for distribution of number of cylinders",xlab="cylinders")

#liters  
screen(2)   
hist(dataset$liters,main="Histogram for distribution of vehicle liters",xlab="liters")

#doors    
screen(1)  
hist(dataset$doors,,main="Histogram for distribution of number of doors",xlab="doors")

#0.5690861 not highly corelated
cor(dataset$price,dataset$cylinders)
screen(1)  
plot(dataset$cylinders,dataset$price,main = "Correlation between Price,Cylinders",xlab="cylinders",ylab="price")
linearmodel <- lm(price~cylinders,data=dataset)
linearmodel
abline(linearmodel)
plot(linearmodel)

# -0.1430505 not highly correlated
cor(dataset$price,dataset$mileage)
screen(2)  
plot(dataset$mileage,dataset$price,,main = "Correlation between Price,Mileage",xlab="mileage",ylab="price")
linearmodel1 <- lm(price~mileage,data=dataset)
abline(linearmodel1)
summary(linearmodel1)

#0.5581458 not highly correlated
cor(dataset$price,dataset$liters)
screen(1)  
plot(dataset$price,dataset$liters,,main = "Correlation between Price,Liters",xlab="liters",ylab="price")
linearmodel2 <- lm(price~liters,data=dataset)
linearmodel2
abline(linearmodel2)
plot(linearmodel2)

# -0.02946099 no correlation
cor(dataset$mileage,dataset$cylinders)
screen(2)  
plot(dataset$mileage,dataset$cylinders,main = "Correlation between Cylinders,Mileage",xlab="cylinders",ylab="mileage")
linearmodel3 <- lm(mileage~cylinders,data=dataset)
linearmodel3
abline(linearmodel3)
plot(linearmodel3)

# -0.01864062 no correlation
cor(dataset$mileage,dataset$liters)
screen(1)  
plot(dataset$mileage,dataset$liters,main = "Correlation between Liters,Mileage",xlab="liters",ylab="mileage")
linearmodel4 <- lm(mileage~liters,data=dataset)
linearmodel4
abline(linearmodel4)
plot(linearmodel4)

# 0.9578966 which shows great correlation between 2 parameters
cor(dataset$liters,dataset$cylinders)
screen(2)  
plot(dataset$liters,dataset$cylinders,main = "Correlation between Cylinders,Liters",xlab="cylinders",ylab="liters")
linearmodel5 <- lm(liters~cylinders,data=dataset)
linearmodel5
abline(linearmodel5)
plot(linearmodel5)

boxplot(dataset$price~dataset$make)
a1 <- aov(price~make,data = dataset)
summary(a1)
TukeyHSD(a1)

boxplot(dataset$price~dataset$model)
a2 <- aov(price~model,data = dataset)
summary(a2)
TukeyHSD(a2)

boxplot(dataset$price~dataset$trim)
a3 <- aov(price~trim,data = dataset)
summary(a3)
TukeyHSD(a3)

?update

multiplelinearmodel <- lm(price~mileage+cylinders+make+model+trim+type+liters+doors+cruise+sound+leather,data=dataset)
summary(multiplelinearmodel)

m1 <- update(multiplelinearmodel,~.-trim)
summary(m1)
anova(multiplelinearmodel,m1)

m2c <- update(m1,~.-cylinders)
summary(m2c)
anova(m1,m2c)

m2 <- update(m1,~.-liters)
summary(m2)
anova(m1,m2)

m3 <- update(m2,~.-doors-cruise-sound-leather)
summary(m3)
anova(m2,m3)

m4 <- update(m3,~.-model)
summary(m4)
anova(multiplelinearmodel,m4)

m5 <- update(m4,~.-mileage)
summary(m5)
anova(multiplelinearmodel,m5)









